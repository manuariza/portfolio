A Pen created at CodePen.io. You can find this one at https://codepen.io/nourabusoud/pen/BxJbjJ.

 A new idea to have all your forms in one place!

P.s all forms lead to the Thank you page for demonstration only.